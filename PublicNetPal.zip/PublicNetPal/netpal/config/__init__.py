# NetPal configuration package.
# This package contains static configuration files shipped with the package
# (ai_prompts.json, exploit_tools.json).
